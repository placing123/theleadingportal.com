<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-08-15 15:16:53 --> Severity: Notice --> Undefined property: Dashboard::$import /home/ltx8i4fswi8y/cvportals.com/application/controllers/admin/Dashboard.php 100
ERROR - 2022-08-15 15:16:53 --> Severity: error --> Exception: Call to a member function insert() on null /home/ltx8i4fswi8y/cvportals.com/application/controllers/admin/Dashboard.php 100
